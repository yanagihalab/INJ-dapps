use crate::doc;

doc::link_doc_comment!(carrying_add, borrowing_sub, widening_mul, carrying_mul);
