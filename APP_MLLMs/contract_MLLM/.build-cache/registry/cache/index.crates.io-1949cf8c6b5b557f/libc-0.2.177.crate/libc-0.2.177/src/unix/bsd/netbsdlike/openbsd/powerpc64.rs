use crate::prelude::*;

pub(crate) const _ALIGNBYTES: usize = size_of::<c_long>() - 1;

pub const _MAX_PAGE_SHIFT: u32 = 12;
